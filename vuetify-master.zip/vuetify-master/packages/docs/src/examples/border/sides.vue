<template>
  <v-container>
    <v-row justify="space-around">
      <v-col cols="auto">
        <div class="text-center">
          <div class="border border-t-lg" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-t-lg</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="border border-e-lg" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-e-lg</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="border border-b-lg" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-b-lg</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="border border-s-lg" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-s-lg</div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>
