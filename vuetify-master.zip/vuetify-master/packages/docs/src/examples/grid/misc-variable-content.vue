<template>
  <v-container class="bg-grey-lighten-5">
    <v-row
      class="mb-6"
      justify="center"
      no-gutters
    >
      <v-col lg="2">
        <v-card
          class="pa-2"
          rounded="0"
          variant="outlined"
        >
          1 of 3
        </v-card>
      </v-col>
      <v-col md="auto">
        <v-card
          class="pa-2"
          rounded="0"
          variant="outlined"
        >
          Variable width content
        </v-card>
      </v-col>
      <v-col lg="2">
        <v-card
          class="pa-2"
          rounded="0"
          variant="outlined"
        >
          3 of 3
        </v-card>
      </v-col>
    </v-row>
    <v-row no-gutters>
      <v-col>
        <v-card
          class="pa-2"
          rounded="0"
          variant="outlined"
        >
          1 of 3
        </v-card>
      </v-col>
      <v-col md="auto">
        <v-card
          class="pa-2"
          rounded="0"
          variant="outlined"
        >
          Variable width content
        </v-card>
      </v-col>
      <v-col lg="2">
        <v-card
          class="pa-2"
          rounded="0"
          variant="outlined"
        >
          3 of 3
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>
