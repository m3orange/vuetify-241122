<template>
  <v-sheet class="d-flex flex-wrap-reverse bg-surface-variant">
    <v-sheet class="order-3 pa-2 ma-2">
      First flex item
    </v-sheet>

    <v-sheet class="order-2 pa-2 ma-2">
      Second flex item
    </v-sheet>

    <v-sheet class="order-1 pa-2 ma-2">
      Third flex item
    </v-sheet>
  </v-sheet>
</template>
