<template>
  <div class="d-flex align-center justify-center px-4">
    <small class="font-weight-bold text-no-wrap">Powered By</small>

    <SponsorCard
      min-height="64"
      slug="made-with-vuejs"
      width="180"
    />
  </div>
</template>
