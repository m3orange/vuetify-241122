<template>
  <section
    id="ready-for-more"
    class="mt-16"
  >
    <DocReadyForMore />

    <DocRelatedPages />

    <AppDivider />

    <DocUpNext />

    <DocContribute />
  </section>
</template>
